#### DESTINATARI DELLA MAIL:
```
TO: romeo.rizzi@univr.it
CC: andrea.cracco@studenti.univr.it
```
---
#### SUBJECT DELLA MAIL:
```
LINK ALLO STREAMING DEL MIO ESAME DI ALGORITMI
```
---
#### BODY DELLA MAIL:
```
MATRICOLA: VR???
NOME: ???
COGNOME: ???
LINK: ???
```

Ovviamente i 4 campi contrassegnati da `???i???` per `i` in {`1`,`2`,`3`,`4`} sono quelli che dovrai personalizzare prima di procedere all'invio.
